# discord-reCAPTCHA

This is an advanced reCaptcha verification system for new members in discord server.

## Requirements!

- NodeJS verson with 16.9.0 or later
- NPM version with 7.0 or later
- A Discord Application with bot account
- Google reCAPTCHA v2 API
-

## Result

https://user-images.githubusercontent.com/65409152/193441607-50d3728b-0db6-4057-85c6-1ba28ac2c005.mp4
