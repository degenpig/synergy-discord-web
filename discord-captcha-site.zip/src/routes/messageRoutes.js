const express = require('express');
const client = require('../../src/index');
const MessageRouter = express.Router();

var msgArry = [];
//for fetch or get products from db
// Fetch a channel by its id

function getFormatDate(m) {
    var dateString = m.getUTCFullYear() +"/"+ (m.getUTCMonth()+1) +"/"+ m.getUTCDate() + " " + m.getUTCHours() + ":" + m.getUTCMinutes() + ":" + m.getUTCSeconds();
    return dateString;
}
client.on('ready', () => {
    const channelID = '1031838896834744320'; //this is your channelID
    const channel = client.channels.cache.get(channelID);
    channel.messages.fetch({ limit: 100 }).then(messages => {
    console.log(`Received ${messages} messagesA`);
    messages.map((item) => {
      console.log('item:', item.content)
      var date = new Date(item.createdTimestamp);
      var formatDate = getFormatDate(date)
      var value = {
        "id": item.author.id,
        "name": item.author.username,
        "date": formatDate,
        "content": item.content
      }
      msgArry.push(value);
    })
})
});
client.on('messageCreate', async(msg) => {
  if (msg.content === 'ping') {
    msg.reply('Pong!');
  }
await msg.channel.messages.fetch({ limit: 100 }).then(messages => {
 console.log(`Received ${messages.size} messages`);
 msgArry = [];
 messages.map((item) => {
      console.log('item:', item.content)
      var date = new Date(item.createdTimestamp);
      var formatDate = getFormatDate(date)
      var value = {
        "id": item.author.id,
        "name": item.author.username,
        "date": formatDate,
        "content": item.content
      }
      msgArry.push(value);
    })
 //console.log("msgddddddd:", msg.content);
 });
});

function getMessages() {
   return msgArry;
}
MessageRouter.get("/", async(req, res) => {
    console.log("Thanks")
    // const products = await Product.find();
    var messageArry = await getMessages();
    //r_messageArray = await messageArry.reverse();
    console.log("TOP:", messageArry)
    await res.send(messageArry)
    //msgArry = [];
});

module.exports = MessageRouter;

// export default MessageRouter;