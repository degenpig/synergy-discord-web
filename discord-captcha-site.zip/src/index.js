require('dotenv').config({path: __dirname + '/../.env' });

const {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
} = require('discord.js');

const client = new Client({
  allowedMentions: { parse: ['users', 'roles'], repliedUser: true },
  partials: [
    Partials.User,
    Partials.Channel,
    Partials.Message,
    Partials.GuildMember,
  ],
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent,
  ],
});

module.exports = client;
console.log("lala", process.env.TOKEN, __dirname + '/../.env')
client.on('ready', () => {
    const channelID = '1031838896834744320'; //this is your channelID
    const channel = client.channels.cache.get(channelID);
    channel.messages.fetch({ limit: 100 }).then(messages => {
    console.log(`Received ${messages.size} messages`);
})
});

client.login(process.env.TOKEN);
// {path: __dirname + '/.env' }
// client.on('guildMemberAdd', member => {
//   console.log("I invited you!")
//   const embed = new EmbedBuilder()
//     .setTitle('Verification')
//     .setDescription(
//       `Please solve reCAPTCHA here:${process.env.CALLBACK_URL}\nBefore accessing to the server!`,
//     );

//   member.send({ embeds: [embed] });
// });

require('./server');
